<!DOCTYPE html>
<?php 
/** Name: deleteContact.php
 *  Description:
 *  Locates a contact for the customer
 */




include_once ("resource/db_conn.php");
$name = $_GET['name'];
$id = $_GET['id'];
$sql = "DELETE FROM `customer_contacts` WHERE `fk_customerID`='$id' AND `LastName`='$name'";
mysql_query($sql);
header('Location: CustomerEdit.php?ID='.$id);

?>
