<!DOCTYPE html> 
<!-- 
    /** Name: viewSupplierProducts.php
     *  Description: 
     *          Views all the suppliers associated with this product.
     */
-->
<?php
include_once ("resource/db_conn.php");
//include_once ("resource/db_connWY.php");
/** Name: mysql_query
 * 	Query database for supplier data.
 *      $query -  string Contains SQL string to query database table
 *      $result -  string Stores the results of the query
 *      Return - Supplier table data
 */
$productID = $_GET['productID'];
$query = "SELECT * FROM `supplier_products` WHERE `fkProductID`='$productID'";
$result = mysql_query($query);

$productquery = "SELECT * FROM `products` WHERE `ProductID`='$productID'";
$productresult = mysql_query($productquery);
$product = mysql_fetch_array($productresult);
$productName = $product['ProductName'];

?>


<html> 
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>PrintFlow - <?php echo $productName; ?></title>
		<!-- add favicon -->        
        <link rel="icon" type="image/png" href="images/logo-transparent.png" />

		<!-- site general style -->
		<link rel="Stylesheet" type="text/css" href="style/basic_css.css"/>    
		<!-- general record style -->
		<link rel="Stylesheet" type="text/css" href="style/record_css.css"/>  
		<!-- specific Quote Record style -->
		<link rel="Stylesheet" type="text/css" href="style/viewSupplierProducts.css"/> 
		
		<!-- include jquery and dataTables plugin -->
		<script type="text/javascript" src="js/jquery-1.10.2.js"></script>
		<script type="text/javascript" src="js/jquery.dataTables.js"></script>
		<!-- creating scrollable and searchable table with non scrolling header.
			 functionality from dataTables plugin -->
		<script type="text/JavaScript">
			$(document).ready(function() {
			   $('#sortable').dataTable( {
				   "sScrollY": "435px",
				   "bPaginate": false,
				   "bScrollCollapse": true
			   } );
			} );     
	   </script>
		
		<!-- Included javascript functions -->
		<script src="scripts/addSupplierFunction.js"></script>
		<script src="scripts/selectRow.js"></script>
		<script src="scripts/scrollingHighlight.js"></script>
		<script src="scripts/selectedSuppliers.js"></script>

		<script type="text/JavaScript">
			
		</script>
		
		<script type="text/javascript" src="scripts/selectSuppliers.js"></script>
            
    </head>
   
    <body>
        <!-- Top header bar contains page title and action buttons  -->
        <header>
            <div id="title">
                <h1><?php echo $productName; ?></h1>            
            </div> <!-- end div - title -->
            <!-- div for tools -->
            <div id="tools">
            </div> <!-- end div - tools -->
         </header> <!-- end header -->
         
        <!-- Main Content area -->
        <div id="content">            
            <!-- Sortable scrollable table contained in div for styling -->
            <div id="tableContainer">
                <table id="sortable" class="sortable">
                    <!-- header row for table -->
                    <thead class="fixedHeader">
                        <tr class="headerRow">
                            <th class="column1">Supplier Name</th>
                        </tr>
                    </thead>
                    <!-- scrollable table body -->
                    <tbody class="scrollContent">
                        <?php
                        if($result) {
                        $temp=0;
                                while($row = mysql_fetch_array($result)) {
										// gets the supplier info
										$supplierID = $row['fkSupplierID'];
										$supplierquery = "SELECT * FROM supplier WHERE `supplierID`='$supplierID'";
										$supplier = mysql_fetch_array(mysql_query($supplierquery));
                                        if($temp%2==0){
                                                echo "<tr onmouseover='scrollingHighlight(this,".$row['SupplierID'].")' onclick='selectRow(this,".$row['SupplierID'].")' ondblclick='supplierHistoryDirect(".$row['SupplierID'].")'>";
                                        //color roll
                                        }
                                        else {
                                                echo "<tr onclick='selectRow(this,".$row['SupplierID'].")' ondblclick='supplierHistoryDirect(".$row['SupplierID'].")' >";
                                        }
                        ?>
                                <td TF_colKey="supplier" name="supplier" id="supplier"><?php echo $supplier['SupplierName']; ?></td>

                        <?php
                                }
                        }
                        ?>
                    </tbody>
                </table>
            </div> <!-- end div - tableContainer -->
        </div> <!-- end div - content -->
    </body>
</html>
