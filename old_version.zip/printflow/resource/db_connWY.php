<!-- to connect to database on WY Wamp server
-->

<?php
    ini_set('display_errors', 1);
    error_reporting(-1);
    $server = 'localhost';
    $username = 'root';
    $password = 'Titan1sBoss';
    $database = 'printflow';
    $connect = mysql_connect( $server, $username, $password ) or die( "MySQL connection error" );
    mysql_select_db($database, $connect);

?>
