<?php
/*

The sole purpose of this file is to prevent
accidential directory listing if the webserver's
configuration is non-ideal.

For example, on the current web server .htaccess
overrides might not be enabled, in which case this file
at least prevents a directory listing.

*/
?>