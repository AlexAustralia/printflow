<?php
require_once(UL_INC_DIR.'/LoginBackend.inc.php');

class ulOpenIdLoginBackend extends ulLoginBackend
{
	private $LightOID = NULL;
  private $ReqAttribs = array();
  private $OptAttribs = array();

	public function __construct()
	{
		try
		{
			$this->LightOID = new LightOpenID(UL_DOMAIN);
			if ($this->LightOID->mode)
			{
				$this->OIDAuth();
			}
		}
		catch (ErrorException $e)
		{
		}		
	}
	
	private function OIDAuth()
	{
		if($this->LightOID->mode == 'cancel')
			return ulLoginBackend::BAD_CREDENTIALS;
	
		if ($this->LightOID->validate())
		{
			$this->AuthResult = $this->LightOID->identity;
			return true;
		}
		else
		{
			$this->AuthResult = false;
			return ulLoginBackend::BAD_CREDENTIALS;
		}
	}
	
  // Returns true if it is possible to perform user authentication by the
	// current settings. False otherwise.  Used to check configuration.
	public function AuthTest()
	{
		return class_exists('LightOpenID');
	}

	// Tries to authenticate a user against the backend.
	// Returns true is successfully authenticated,
	// or an error code otherwise.
	public function Authenticate($uid, $pass)
	{
		try
		{
			if (!$this->LightOID->mode || ($uid != $this->LightOID->identity))
			{
				// Some providers need a special identifier
				if ((strpos($uid, '@gmail')!==false) || (strpos($uid, '@google')!==false))
					$this->LightOID->identity = 'https://www.google.com/accounts/o8/id';
				else if ((strpos($uid, '@yahoo')!==false) || (strpos($uid, '@rocketmail.com')!==false) || (strpos($uid, '@ymail.com')!==false))
					$this->LightOID->identity = 'https://me.yahoo.com';
				else
					$this->LightOID->identity = $uid;
					
        $this->LightOID->required = $this->ReqAttribs;
        $this->LightOID->optional = $this->OptAttribs;
				header('Location: ' . $this->LightOID->authUrl());
				exit(0);
			}
			else
			{
				return $this->OIDAuth();
			}
		}
		catch (ErrorException $e)
		{
			return ulLoginBackend::ERROR;
		}		
	}
  
  // Requests OpenID attributes from the OpenID provider before calling Authenticate().
  // Each attribute is specified as an AX schema path (eg. "contact/email").
  // $attributes is either a single attribute or an array of attributes.
  // This method can be called multiple times, and the list of requested
  // attributes is extended upon each call.
  // If bOptional is true, the OpenID provider might let the user select if they
  // want to disclose the attribute's value to the current website.
  // Depending on the provider, an attribute's value might not be returned 
  // even if it was requested as non-optional.
  // Upon successfull login, attributes can be retrieved using GetAttributes().
  public function RequestAttributes($attributes, $bOptional=false)
  {
    if ($bOptional)
    {
      if (is_array($attributes))
        $this->OptAttribs = array_merge($this->OptAttribs, $attributes);
      else
        array_push($this->OptAttribs, $attributes);
    } else {
      if (is_array($attributes))
        $this->ReqAttribs = array_merge($this->ReqAttribs, $attributes);
      else
        array_push($this->ReqAttribs, $attributes);
    }
  }

  // Returns an associative list of requested attributes, where for each element
  // the key is the AX schema path and the value is the attribute's value
  // as returned from the OpenID provider.
  public function GetAttributes()
  {
	  if (($this->LightOID->mode) && ($this->LightOID->mode != 'cancel'))
      return $this->LightOID->getAttributes();
    else
      // Attributes may only be retrieved immediately after a 
      // successfull OpenID login.
      return ulLoginBackend::INVALID_OP;
  }

	// Given the backend-specific unique identifier, returns
	// a unique identifier that can be displayed to the user.
	// False on error.
	public function Username($uid)
	{
		return $uid;
	}

	// Given a user-friendly unique identifier, returns
	// a backed-specific unique identifier.
	// False on error.
	public function Uid($username)
	{
		return $username;
	}

	// Sets the timestamp of the last login for the 
	// specified user to NOW. True on success or error code.
	public function UpdateLastLoginTime($uid)
	{
		return true;
	}	

	// Creates a new login for a user.
	// Returns true if successful, or an error code.
	// The format of the $profile parameter is backend-specific
	// and need not/may not be supported by the current backend.
	public function CreateLogin($username, $password, $profile)
	{
		return ulLoginBackend::NOT_SUPPORTED;
	}

	// Deletes a login from the database.
	// Returns true if successful, an error code otherwise.
	public function DeleteLogin($dn)
	{
		return ulLoginBackend::NOT_SUPPORTED;
	}

	// Changes the password for an already existing login.
	// Returns true if successful, an error code otherwise.
	public function SetPassword($dn, $pass)
	{
		return ulLoginBackend::NOT_SUPPORTED;
	}

	// Blocks or unblocks a user.
	// Set $block to a positive value to block for that many seconds.
	// Set $block to zero or negative to unblock.
	// Returns true on success, otherwise an error code.
	public function BlockUser($dn, $block_secs)
	{
		return true;
	}

	// If the user is blocked, returns a DateTime (local timezone) object
	// telling when to unblock the user. If a past block expired
	// or the user is not blocked, returns a DateTime from the past.
	// Can also return error codes.
	protected function UserBlockExpires($dn, &$flagged)
	{
		return new DateTime('1000 years ago');
	}
}

?>