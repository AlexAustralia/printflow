<?php
require_once(UL_INC_DIR.'/LoginBackend.inc.php');

class ulLdapLoginBackend extends ulLoginBackend
{
	// Returns true if it is possible to perform user authentication by the
	// current settings. False otherwise.  Used to check cnfiguration.
	public function AuthTest()
	{
		if (!function_exists('ldap_bind'))
			return false;
	
		$db = new ulLdapDb();
		return $db->Bind(UL_LDAP_SEARCH_DN, UL_LDAP_SEARCH_PWD);
	}

	// Returns true if remember-me functionality can be used
	// with this backend.
	public function IsAutoLoginAllowed()
	{
		return true;
	}

	// Tries to authenticate a user against the backend.
	// Returns true is sccessfully authenticated,
	// or an error code otherwise.
	public function Authenticate($dn, $pass)
	{
		$db = new ulLdapDb();
		if ($db->Bind($dn, $pass))
		{
			$this->AuthResult = $dn;
			return true;
		}
		else
		{
			$this->AuthResult = false;

			// LDAP in PHP only connects upon bind, so we cannot know
			// if this error is because of a false configuration or 
			// bad credentials. So return a generic error.
			return ulLoginBackend::ERROR;
		}
	}
	
	// Given the backend-specific unique identifier, returns
	// a unique identifier that can be displayed to the user.
	// False on error.
	public function Username($dn)
	{
		$db = new ulLdapDb();
		if (!$db->Bind(UL_LDAP_SEARCH_DN, UL_LDAP_SEARCH_PWD))
		{
			$db->Fail();
			return false;
		}

		$entry = $db->ReadEntry($dn, array(UL_LDAP_NICK_ATTRIB));
		if ($entry === false)
		{
			$db->Fail();
			return false;
		}
			
		if ($entry['count'] == 0)
			return false;
			
		return $entry[0][UL_LDAP_NICK_ATTRIB][0];
	}

	// Given a user-friendly unique identifier, returns
	// a backed-specific unique identifier.
	// False on error.
	public function Uid($username)
	{
		$dn = str_replace('[username]', $username, UL_LDAP_DN_TEMPLATE);
	
		// Need to check if Uid exists
		$db = new ulLdapDb();
		if (!$db->Bind(UL_LDAP_SEARCH_DN, UL_LDAP_SEARCH_PWD))
		{
			$db->Fail();
			return false;
		}

		$entry = $db->ReadEntry($dn, array(UL_LDAP_NICK_ATTRIB));
		if ($entry === false)
		{
			return false;
		}
		
		return $dn;
	}

	// Sets the timestamp of the last login for the 
	// specified user to NOW. True on success or error code.
	function UpdateLastLoginTime($dn)
	{
		return true;
	}	

	// Creates a new login for a user.
	// Returns true if successful, or an error code.
	// The format of the $profile parameter is backend-specific
	// and need not/may not be supported by the current backend.
	function CreateLogin($username, $password, $profile)
	{
		$dn = str_replace('[username]', $username, UL_LDAP_DN_TEMPLATE);
		$pwdhash = ulPassword::Hash($password, UL_LDAP_PWD_HASH);

		$db = new ulLdapDb();
		if (!$db->Bind(UL_LDAP_PRIVILEGED_DN, UL_LDAP_PRIVILEGED_PWD))
		{
			$db->Fail();
			return ulLoginBackend::ERROR;
		}
			
		$profile[UL_LDAP_NICK_ATTRIB] = $username;
		$profile[UL_LDAP_PWD_ATTRIB] = $pwdhash;
		if (@ldap_add($db->con, $dn, $profile))
			return true;
		else
			return ulLoginBackend::ERROR;
	}

	// Deletes a login from the database.
	// Returns true if successful, an error code otherwise.
	public function DeleteLogin($dn)
	{
		$db = new ulLdapDb();
		if (!$db->Bind(UL_LDAP_PRIVILEGED_DN, UL_LDAP_PRIVILEGED_PWD))
		{
			$db->Fail();
			return ulLoginBackend::ERROR;
		}
			
		if (ldap_delete($db->con, $dn))
			return true;
		else
			return ulLoginBackend::ERROR;
	}

	// Changes the password for an already existing login.
	// Returns true if successful, an error code otherwise.
	public function SetPassword($dn, $pass)
	{
		$binddn = UL_LDAP_PRIVILEGED_DN;
		$bindpwd = UL_LDAP_PRIVILEGED_PWD;

		$db = new ulLdapDb();
		if (!$db->Bind($binddn, $bindpwd))
		{
			$db->Fail();
			return ulLoginBackend::ERROR;
		}

		$attribute[UL_LDAP_PWD_ATTRIB] = ulPassword::Hash($password, UL_LDAP_PWD_HASH);
		if (ldap_mod_replace($db->con, $dn, $attribute))
			return true;
		else
			return ulLoginBackend::ERROR;
	}

	// Blocks or unblocks a user.
	// Set $block to a positive value to block for that many seconds.
	// Set $block to zero or negative to unblock.
	// Returns true on success, otherwise an error code.
	public function BlockUser($dn, $block_secs)
	{
		$db = new ulLdapDb();
		if (!$db->Bind(UL_LDAP_PRIVILEGED_DN, UL_LDAP_PRIVILEGED_PWD))
		{
			$db->Fail();
			return ulLoginBackend::ERROR;
		}

		if ($block_secs > 0)
		{
			$attribute['pwdAccountLockedTime'] = ulLdapDb::DateTimeToLdap(new DateTime('now'));
			if (!ldap_mod_add($db->con, $dn, $attribute))
				return ulLoginBackend::ERROR;
		}
		else
		{
			$attribute['pwdAccountLockedTime'] = array();
			if (!ldap_mod_del($db->con, $dn, $attribute))
				return ulLoginBackend::ERROR;
		}
		
		return true;
	}

	// If the user is blocked, returns a DateTime (local timezone) object
	// telling when to unblock the user. If a past block expired
	// or the user is not blocked, returns a DateTime from the past.
	// Can also return error codes.
	protected function UserBlockExpires($dn, &$flagged)
	{
		$db = new ulLdapDb();
		if (!$db->Bind(UL_LDAP_PRIVILEGED_DN, UL_LDAP_PRIVILEGED_PWD))
		{
			return ulLoginBackend::ERROR;
			$db->Fail();
		}

		$entry = $db->ReadEntry($dn, array('pwdAccountLockedTime'));
		if ($entry === false)
			return ulLoginBackend::NO_SUCH_USER;	// Most probable
			
		if ($entry['count'] == 0)
			return ulLoginBackend::ERROR;
			
		$expires = NULL;
		$flagged = false;
		if (isset($entry[0]['pwdaccountlockedtime']))
		{
			$lockedTime = ulLdapDb::DateTimeFromLdap($entry[0]['pwdaccountlockedtime'][0]);
			$di = new DateInterval('PT'.UL_BF_USER_LOCKOUT.'S');
			$expires = $lockedTime->add($di);
			$flagged = true;
		}

		return ($expires == NULL) ? new DateTime('1000 years ago') : $expires; 
	}
}

?>