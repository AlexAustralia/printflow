<?php
require_once(UL_INC_DIR.'/LoginBackend.inc.php');

class ulDuoSecLoginBackend extends ulLoginBackend
{
	public function __construct()
	{
		if (isset($_POST['sig_response']))
		{
			$this->DuoAuth();
		}
	}

	private function DuoAuth()
	{
		$this->AuthResult = false;

		// Verify nonce first
		if (!isset($_POST['ulDuoSecLoginNonce']))
			return ulLoginBackend::ERROR;

		if (!ulNonce::Verify('ulDuoSecLogin', $_POST['ulDuoSecLoginNonce']))
			return ulLoginBackend::ERROR;
	
		//make sure that verifyResponse does not return NULL
		//if it is NOT NULL then it will return a username
		//you can then set any cookies/session data for that username
		//and complete the login process
		$resp = Duo::verifyResponse(UL_DUOSEC_IKEY, UL_DUOSEC_SKEY, UL_DUOSEC_AKEY, $_POST['sig_response']);
		if($resp != NULL)
		{
			$this->AuthResult = $resp;
			return true;
		}
		else
		{
			return ulLoginBackend::BAD_CREDENTIALS;
		}
	}

    // Returns true if it is possible to perform user authentication by the
	// current settings. False otherwise.  Used to check cnfiguration.
	public function AuthTest()
	{
		return true;
	}

	// Tries to authenticate a user against the backend.
	// Returns true is sccessfully authenticated,
	// or an error code otherwise.
	public function Authenticate($uid, $pass)
	{
		if (!isset($_POST['sig_response']))
		{
			// If you need to modify how the Duo Security authentication page looks like
			// you need to modify the included PHP file below.
			include UL_INC_DIR.'/duosec/DuoShowAuth.inc.php';
			exit(0);
		}
		else
		{
			return $this->DuoAuth();
		}
	}

	// Given the backend-specific unique identifier, returns
	// a unique identifier that can be displayed to the user.
	// False on error.
	public function Username($uid)
	{
		return $uid;
	}

	// Given a user-friendly unique identifier, returns
	// a backed-specific unique identifier.
	// False on error.
	public function Uid($username)
	{
		return $username;
	}

	// Sets the timestamp of the last login for the 
	// specified user to NOW. True on success or error code.
	public function UpdateLastLoginTime($uid)
	{
		return true;
	}	

	// Creates a new login for a user.
	// Returns true if successful, or an error code.
	// The format of the $profile parameter is backend-specific
	// and need not/may not be supported by the current backend.
	public function CreateLogin($username, $password, $profile)
	{
		return ulLoginBackend::NOT_SUPPORTED;
	}

	// Deletes a login from the database.
	// Returns true if successful, an error code otherwise.
	public function DeleteLogin($dn)
	{
		return ulLoginBackend::NOT_SUPPORTED;
	}

	// Changes the password for an already existing login.
	// Returns true if successful, an error code otherwise.
	public function SetPassword($dn, $pass)
	{
		return ulLoginBackend::NOT_SUPPORTED;
	}

	// Blocks or unblocks a user.
	// Set $block to a positive value to block for that many seconds.
	// Set $block to zero or negative to unblock.
	// Returns true on success, otherwise an error code.
	public function BlockUser($dn, $block_secs)
	{
		return true;
	}

	// If the user is blocked, returns a DateTime (local timezone) object
	// telling when to unblock the user. If a past block expired
	// or the user is not blocked, returns a DateTime from the past.
	// Can also return error codes.
	protected function UserBlockExpires($dn, &$flagged)
	{
		return new DateTime('1000 years ago');
	}
}

?>