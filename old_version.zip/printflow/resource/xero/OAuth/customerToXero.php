<?php
// connects to the database
include_once ("../../db_conn.php");
// include XeroOAuth library
require 'lib/XeroOAuth.php';

// data pulled from database to send to xero

// customer ID
$id = $_GET['id'];

// selects the customer
$customerSQL = "SELECT * FROM `customer` WHERE `CustomerID` = '$id'";
$customer = mysql_fetch_array(mysql_query($customerSQL));

// selects the primary contact
$contactSQL = "SELECT * FROM `customer_contacts` WHERE `fk_customerID` = '$id' AND `PrimaryContact` = '1'";
$contact = mysql_fetch_array(mysql_query($contactSQL));

// selects the other contacts
$otherContactsSQL = "SELECT * FROM `customer_contacts` WHERE `fk_customerID` = '$id' AND `PrimaryContact` != '1'";
$otherContacts = mysql_query($otherContactsSQL);
$contactsXML = '<ContactPersons>';
while($row = mysql_fetch_array($otherContacts)) {
	$contactsXML .= 
	'<ContactPerson>
		<FirstName>'.$row['FirstName'].'</FirstName>
		<LastName>'.$row['LastName'].'</LastName>
		<EmailAddress>'.$row['Email'].'</EmailAddress>
	</ContactPerson>';
}
$contactsXML .= '</ContactPersons>';

// selects the primary account
$accountSQL = "SELECT * FROM `customer_accounts` WHERE `fk_customerID` = '$id' AND `PrimaryAccount` = '1'";
$account = mysql_fetch_array(mysql_query($accountSQL));

// constants, change from here to update keys, useragent etc.
define('BASE_PATH',dirname(__FILE__));
define ( "XRO_APP_TYPE", "Private" );
define ( "OAUTH_CALLBACK", 'http://localhost/PrintFlow/customerView.php' );
$useragent = "PrintFlow";

$signatures = array (
		'consumer_key'     => 'SHAH0PAEVZZHMR4CBK8XAZUJSUPW1I',
		'shared_secret'    => '16HBMGPS6BSC4AB9IOJKKCMP7G8KZX',
		// API versions
		'core_version' => '2.0',
		'payroll_version' => '1.0' 
);

if (XRO_APP_TYPE == "Private" || XRO_APP_TYPE == "Partner") {
	$signatures ['rsa_private_key'] = BASE_PATH . '/certs/privatekey.pem';
	$signatures ['rsa_public_key'] = BASE_PATH . '/certs/publickey.cer';
}

$XeroOAuth = new XeroOAuth ( array_merge ( array (
		'application_type' => XRO_APP_TYPE,
		'oauth_callback' => OAUTH_CALLBACK,
		'user_agent' => $useragent 
), $signatures ) );

// functions required to establish connection

function testLinks()
{
}


/**
 * Persist the OAuth access token and session handle
 */
function persistSession($response)
{
    if (isset($response)) {
        $_SESSION['access_token']       = $response['oauth_token'];
        $_SESSION['oauth_token_secret'] = $response['oauth_token_secret'];
      	if(isset($response['oauth_session_handle']))  $_SESSION['session_handle']     = $response['oauth_session_handle'];
    } else {
        return false;
    }

}


/**
 * Retrieve the OAuth access token and session handle
 */
function retrieveSession()
{
    if (isset($_SESSION['access_token'])) {
        $response['oauth_token']            =    $_SESSION['access_token'];
        $response['oauth_token_secret']     =    $_SESSION['oauth_token_secret'];
        $response['oauth_session_handle']   =    $_SESSION['session_handle'];
        return $response;
    } else {
        return false;
    }

}

function outputError($XeroOAuth)
{
	echo $customerName;
    echo 'Error: ' . $XeroOAuth->response['response'] . PHP_EOL;
    pr($XeroOAuth);
}

/**
 * Debug function for printing the content of an object
 *
 * @param mixes $obj
 */
function pr($obj)
{

    if (!is_cli())
        echo '<pre style="word-wrap: break-word">';
    if (is_object($obj))
        print_r($obj);
    elseif (is_array($obj))
        print_r($obj);
    else
        echo $obj;
    if (!is_cli())
        echo '</pre>';
}

function is_cli()
{
    return (PHP_SAPI == 'cli' && empty($_SERVER['REMOTE_ADDR']));
}

// end functions

// establishes connection

$initialCheck = $XeroOAuth->diagnostics ();
$checkErrors = count ( $initialCheck );
if ($checkErrors > 0) {
	// you could handle any config errors here, or keep on truckin if you like to live dangerously
	foreach ( $initialCheck as $check ) {
		echo 'Error: ' . $check . PHP_EOL;
	}
} else {
	$session = persistSession ( array (
			'oauth_token' => $XeroOAuth->config ['consumer_key'],
			'oauth_token_secret' => $XeroOAuth->config ['shared_secret'],
			'oauth_session_handle' => '' 
	) );
	$oauthSession = retrieveSession ();
	
	if (isset ( $oauthSession ['oauth_token'] )) {
		$XeroOAuth->config ['access_token'] = $oauthSession ['oauth_token'];
		$XeroOAuth->config ['access_token_secret'] = $oauthSession ['oauth_token_secret'];
		
		//include 'tests/tests.php';
				
		if (isset($_REQUEST)){
			if (!isset($_REQUEST['where'])) $_REQUEST['where'] = "";
		}
			
		if ( isset($_REQUEST['wipe'])) {
		  session_destroy();
		  header("Location: {$here}");

		// already got some credentials stored?
		} elseif(isset($_REQUEST['refresh'])) {
			$response = $XeroOAuth->refreshToken($oauthSession['oauth_token'], $oauthSession['oauth_session_handle']);
			if ($XeroOAuth->response['code'] == 200) {
				$session = persistSession($response);
				$oauthSession = retrieveSession();
			} else {
				outputError($XeroOAuth);
				if ($XeroOAuth->response['helper'] == "TokenExpired") $XeroOAuth->refreshToken($oauthSession['oauth_token'], $oauthSession['session_handle']);
			}

		} elseif ( isset($oauthSession['oauth_token']) && isset($_REQUEST) ) {

			$XeroOAuth->config['access_token']  = $oauthSession['oauth_token'];
			$XeroOAuth->config['access_token_secret'] = $oauthSession['oauth_token_secret'];
			$XeroOAuth->config['session_handle'] = $oauthSession['oauth_session_handle'];
			
			if( isset($_REQUEST['contacts'])) {
			   if (!isset($_REQUEST['method'])) {
				   $response = $XeroOAuth->request('GET', $XeroOAuth->url('Contacts', 'core'), array());
				   if ($XeroOAuth->response['code'] == 200) {
					   $contacts = $XeroOAuth->parseResponse($XeroOAuth->response['response'], $XeroOAuth->response['format']);
					   echo "There are " . count($contacts->Contacts[0]). " contacts in this Xero organisation, the first one is: </br>";
					   pr($contacts->Contacts[0]->Contact);
					echo '<script>window.close();</script>';
				   }
				
				   else {
					   outputError($XeroOAuth);
				   }
			   } elseif(isset($_REQUEST['method']) && $_REQUEST['method'] == "post" ){
				   $xml = '<Contacts>
							 <Contact>
							   <Name>'.$customer['CustomerName'].'</Name>
							   <FirstName>'.$contact['FirstName'].'</FirstName>
							   <LastName>'.$contact['LastName'].'</LastName>
							   <EmailAddress>'.$contact['Email'].'</EmailAddress>
							   <Addresses>
									<Address>
										<AddressType>POBOX</AddressType>
										<AttentionTo>'.$contact['FirstName'].'</AttentionTo>
										<AddressLine1>'.$account['Name'].'</AddressLine1>
										<AddressLine2>'.$account['Street'].'</AddressLine2>
										<AddressLine3> </AddressLine3>
										<AddressLine4> </AddressLine4>
										<City>'.$account['Suburb'].'</City>
										<Region>'.$account['State'].'</Region>
										<PostalCode>'.$account['Postcode'].'</PostalCode>
										<Country>'.$account['Country'].'</Country>
									</Address>
									<Address>
										<AddressType>STREET</AddressType>
										<AttentionTo>'.$contact['FirstName'].'</AttentionTo>
										<AddressLine1>'.$customer['CustomerName'].'</AddressLine1>
										<AddressLine2>'.$customer['Address'].'</AddressLine2>
										<AddressLine3>'.$customer['Address2'].'</AddressLine3>
										<AddressLine4> </AddressLine4>
										<City>'.$customer['Suburb'].'</City>
										<Region>'.$customer['State'].'</Region>
										<PostalCode>'.$customer['Postcode'].'</PostalCode>
										<Country>'.$customer['Country'].'</Country>
									</Address>
							   </Addresses>
							   <Phones>
									<Phone>
										<PhoneType>DEFAULT</PhoneType>
										<PhoneNumber>'.$contact['Phone'].'</PhoneNumber>
										<PhoneAreaCode> </PhoneAreaCode>
										<PhoneCountryCode> </PhoneCountryCode>
									</Phone>
									<Phone>
										<PhoneType>MOBILE</PhoneType>
										<PhoneNumber>'.$contact['Mobile'].'</PhoneNumber>
										<PhoneAreaCode> </PhoneAreaCode>
										<PhoneCountryCode> </PhoneCountryCode>
									</Phone>
							   </Phones>
							   <Website>'.$customer['WebAddress'].'</Website>
							 </Contact>
						   </Contacts>
						   ';
				   $response = $XeroOAuth->request('POST', $XeroOAuth->url('Contacts', 'core'), array(), $xml);
				   if ($XeroOAuth->response['code'] == 200) {
					   $contact = $XeroOAuth->parseResponse($XeroOAuth->response['response'], $XeroOAuth->response['format']);
					   echo "" . count($contact->Contacts[0]). " contact created/updated in this Xero organisation.";
					   if (count($contact->Contacts[0])>0) {
						   echo "The first one is: </br>";
						   pr($contact->Contacts[0]->Contact);
					   }
					   echo '<script>window.close();</script>';
				   } else {
					   outputError($XeroOAuth);
				   }
			   }
			   // updating a customer contact
			   elseif(isset($_REQUEST['method']) && $_REQUEST['method'] == "update" ){
					// retrieves the record to be updated
					/*$response = $XeroOAuth->request('GET', $XeroOAuth->url('Contacts', 'core'), array('Where' => 		'Name=="'.$customer['CustomerName'].'"'));
					if ($XeroOAuth->response['code'] == 200) {
					    $contacts = $XeroOAuth->parseResponse($XeroOAuth->response['response'], $XeroOAuth->response['format']);
					    $contactID = $contacts->Contacts[0]->Contact[0]->ContactID;
						echo $contactID;
				    } else {
					    outputError($XeroOAuth);
				    }*/
				   $xml = '<Contacts>
							 <Contact>
							   <Name>'.$customer['CustomerName'].'</Name>
							   <FirstName>'.$contact['FirstName'].'</FirstName>
							   <LastName>'.$contact['LastName'].'</LastName>
							   <EmailAddress>'.$contact['Email'].'</EmailAddress>
							   <Addresses>
									<Address>
										<AddressType>POBOX</AddressType>
										<AttentionTo>'.$contact['FirstName'].'</AttentionTo>
										<AddressLine1>'.$account['Name'].'</AddressLine1>
										<AddressLine2>'.$account['Street'].'</AddressLine2>
										<AddressLine3> </AddressLine3>
										<AddressLine4> </AddressLine4>
										<City>'.$account['Suburb'].'</City>
										<Region>'.$account['State'].'</Region>
										<PostalCode>'.$account['Postcode'].'</PostalCode>
										<Country>'.$account['Country'].'</Country>
									</Address>
									<Address>
										<AddressType>STREET</AddressType>
										<AttentionTo>'.$contact['FirstName'].'</AttentionTo>
										<AddressLine1>'.$customer['CustomerName'].'</AddressLine1>
										<AddressLine2>'.$customer['Address'].'</AddressLine2>
										<AddressLine3>'.$customer['Address2'].'</AddressLine3>
										<AddressLine4> </AddressLine4>
										<City>'.$customer['Suburb'].'</City>
										<Region>'.$customer['State'].'</Region>
										<PostalCode>'.$customer['Postcode'].'</PostalCode>
										<Country>'.$customer['Country'].'</Country>
									</Address>
							   </Addresses>
							   <Phones>
									<Phone>
										<PhoneType>DEFAULT</PhoneType>
										<PhoneNumber>'.$contact['Phone'].'</PhoneNumber>
										<PhoneAreaCode> </PhoneAreaCode>
										<PhoneCountryCode> </PhoneCountryCode>
									</Phone>
									<Phone>
										<PhoneType>MOBILE</PhoneType>
										<PhoneNumber>'.$contact['Mobile'].'</PhoneNumber>
										<PhoneAreaCode> </PhoneAreaCode>
										<PhoneCountryCode> </PhoneCountryCode>
									</Phone>
							   </Phones>
							   <Website>'.$customer['WebAddress'].'</Website>
							   <IsCustomer>true</IsCustomer>
							   '.$contactsXML.'
							 </Contact>
						   </Contacts>';
				   $response = $XeroOAuth->request('POST', $XeroOAuth->url('Contacts', 'core'), array(), $xml);
				   if ($XeroOAuth->response['code'] == 200) {
					   $contact = $XeroOAuth->parseResponse($XeroOAuth->response['response'], $XeroOAuth->response['format']);
					   echo "" . count($contact->Contacts[0]). " contact created/updated in this Xero organisation.";
					   if (count($contact->Contacts[0])>0) {
						   echo "The first one is: </br>";
						   pr($contact->Contacts[0]->Contact);
					   }
					   echo '<script>window.close();</script>';
				   } else {
					   outputError($XeroOAuth);
				   }
			   }
			   elseif(isset($_REQUEST['method']) && $_REQUEST['method'] == "put" ){
			$xml = "<Contacts>
					<Contact>
					  <Name>Orlena Greenville</Name>
					</Contact>
				  </Contacts>";
			$response = $XeroOAuth->request('PUT', $XeroOAuth->url('Contacts', 'core'), array(), $xml);
			  if ($XeroOAuth->response['code'] == 200) {
				$contacts = $XeroOAuth->parseResponse($XeroOAuth->response['response'], $XeroOAuth->response['format']);
				echo "There are " . count($contacts->Contacts[0]). " successful contact(s) created in this Xero organisation.";
				if(count($contacts->Contacts[0])>0){
				  echo "The first one is: </br>";
				  pr($contacts->Contacts[0]->Contact);
				}
				echo '<script>window.location.assign("customerEdit.php?ID='.$id.'");</script>';
			  } else {
				outputError($XeroOAuth); 
				echo 'dddddd';
			  }
		  }
		   }
			
		}
	}
}

