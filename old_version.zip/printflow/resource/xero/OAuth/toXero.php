<?php
// connects to the database
include_once ("../../db_conn.php");
// include XeroOAuth library
require 'lib/XeroOAuth.php';

// data pulled from database to send to xero

// job ID
$id = $_GET['id'];

// selects the job
$jobSQL = "SELECT * FROM `job` WHERE `JobID` = '$id'";
$job = mysql_fetch_array(mysql_query($jobSQL));
// selects the quote
$quoteSQL = "SELECT * FROM `customer_requests` WHERE `CustomerRequestID` = '$id'";
$quote =  mysql_fetch_array(mysql_query($quoteSQL));
$custID = $quote['fkCustomerID'];
// selects the customer
$customerSQL = "SELECT * FROM `customer` WHERE `CustomerID` = '$custID'";
$customer = mysql_fetch_array(mysql_query($customerSQL));
// sets the job's status to Invoice
$jobUpdateSql = "UPDATE `job` SET JobStatus='Invoiced' WHERE `jobID`='$id'";
$jobUpdateResult = mysql_query($jobUpdateSql);

// gets relevant data from the job
$customerName = $customer['CustomerName'];
$date = date('c');
$netCost = $job['JobNetCost'];
$GST = $job['JobGST'];
$totalIncGST = $job['JobGrossSell'];
$quantity = $job['JobQuantity'];
$jobTitle = $job['JobTitle'];
$jobNumber = $job['JobID'];
$PONumber = $job['JobNetCost'];
$jobDescription = $job['JobDescription'];
$jobDescription = ($job['JobDescription']=="") ? 'Not Available' : $job['JobDescription'];
$unitCost = ($netCost / $quantity);
$dueDate = date('Y-m-d', strtotime("+2 weeks"));

// constants, change from here to update keys, useragent etc.
define('BASE_PATH',dirname(__FILE__));
define ( "XRO_APP_TYPE", "Private" );
define ( "OAUTH_CALLBACK", 'http://localhost/PrintFlow/index.php' );
$useragent = "PrintFlow";

$signatures = array (
		'consumer_key'     => 'SHAH0PAEVZZHMR4CBK8XAZUJSUPW1I',
		'shared_secret'    => '16HBMGPS6BSC4AB9IOJKKCMP7G8KZX',
		// API versions
		'core_version' => '2.0',
		'payroll_version' => '1.0' 
);

if (XRO_APP_TYPE == "Private" || XRO_APP_TYPE == "Partner") {
	$signatures ['rsa_private_key'] = BASE_PATH . '/certs/privatekey.pem';
	$signatures ['rsa_public_key'] = BASE_PATH . '/certs/publickey.cer';
}

$XeroOAuth = new XeroOAuth ( array_merge ( array (
		'application_type' => XRO_APP_TYPE,
		'oauth_callback' => OAUTH_CALLBACK,
		'user_agent' => $useragent 
), $signatures ) );

// functions required to establish connection

function testLinks()
{
}


/**
 * Persist the OAuth access token and session handle
 */
function persistSession($response)
{
    if (isset($response)) {
        $_SESSION['access_token']       = $response['oauth_token'];
        $_SESSION['oauth_token_secret'] = $response['oauth_token_secret'];
      	if(isset($response['oauth_session_handle']))  $_SESSION['session_handle']     = $response['oauth_session_handle'];
    } else {
        return false;
    }

}


/**
 * Retrieve the OAuth access token and session handle
 */
function retrieveSession()
{
    if (isset($_SESSION['access_token'])) {
        $response['oauth_token']            =    $_SESSION['access_token'];
        $response['oauth_token_secret']     =    $_SESSION['oauth_token_secret'];
        $response['oauth_session_handle']   =    $_SESSION['session_handle'];
        return $response;
    } else {
        return false;
    }

}

function outputError($XeroOAuth)
{
	echo $customerName;
    echo 'Error: ' . $XeroOAuth->response['response'] . PHP_EOL;
    pr($XeroOAuth);
}

/**
 * Debug function for printing the content of an object
 *
 * @param mixes $obj
 */
function pr($obj)
{

    if (!is_cli())
        echo '<pre style="word-wrap: break-word">';
    if (is_object($obj))
        print_r($obj);
    elseif (is_array($obj))
        print_r($obj);
    else
        echo $obj;
    if (!is_cli())
        echo '</pre>';
}

function is_cli()
{
    return (PHP_SAPI == 'cli' && empty($_SERVER['REMOTE_ADDR']));
}

// end functions

// establishes connection

$initialCheck = $XeroOAuth->diagnostics ();
$checkErrors = count ( $initialCheck );
if ($checkErrors > 0) {
	// you could handle any config errors here, or keep on truckin if you like to live dangerously
	foreach ( $initialCheck as $check ) {
		echo 'Error: ' . $check . PHP_EOL;
	}
} else {
	$session = persistSession ( array (
			'oauth_token' => $XeroOAuth->config ['consumer_key'],
			'oauth_token_secret' => $XeroOAuth->config ['shared_secret'],
			'oauth_session_handle' => '' 
	) );
	$oauthSession = retrieveSession ();
	
	if (isset ( $oauthSession ['oauth_token'] )) {
		$XeroOAuth->config ['access_token'] = $oauthSession ['oauth_token'];
		$XeroOAuth->config ['access_token_secret'] = $oauthSession ['oauth_token_secret'];
		
		//include 'tests/tests.php';
				
		if (isset($_REQUEST)){
			if (!isset($_REQUEST['where'])) $_REQUEST['where'] = "";
		}
			
		if ( isset($_REQUEST['wipe'])) {
		  session_destroy();
		  header("Location: {$here}");

		// already got some credentials stored?
		} elseif(isset($_REQUEST['refresh'])) {
			$response = $XeroOAuth->refreshToken($oauthSession['oauth_token'], $oauthSession['oauth_session_handle']);
			if ($XeroOAuth->response['code'] == 200) {
				$session = persistSession($response);
				$oauthSession = retrieveSession();
			} else {
				outputError($XeroOAuth);
				if ($XeroOAuth->response['helper'] == "TokenExpired") $XeroOAuth->refreshToken($oauthSession['oauth_token'], $oauthSession['session_handle']);
			}

		} elseif ( isset($oauthSession['oauth_token']) && isset($_REQUEST) ) {

			$XeroOAuth->config['access_token']  = $oauthSession['oauth_token'];
			$XeroOAuth->config['access_token_secret'] = $oauthSession['oauth_token_secret'];
			$XeroOAuth->config['session_handle'] = $oauthSession['oauth_session_handle'];
			
			if (isset($_REQUEST['invoice'])) {
				if (isset($_REQUEST['method']) && $_REQUEST['method'] == "post" ) {
					$xml = '<Invoices>
							  <Invoice>
								<Type>ACCREC</Type>
								<Contact>
								  <Name>'.$customerName.'</Name>
								</Contact>
								<Status>SUBMITTED</Status>
								<Date>'.$date.'</Date>
								<DueDate>'.$dueDate.'</DueDate>
								<Reference>'.$id.'</Reference>
								<LineAmountTypes>Exclusive</LineAmountTypes>
								<LineItems>
								  <LineItem>
									<JobNo>'.$jobNumber.'</JobNo>
									<Title>'.$jobTitle.'</Title>
									<Description>'.$jobTitle.'</Description>
									<UnitAmount>'.$unitCost.'</UnitAmount>
									<GST>'.$GST.'</GST>
									<AccountCode>230/</AccountCode>
									<TotalIncGST>'.$totalIncGST.'</TotalIncGST>
									<Quantity>'.$quantity.'</Quantity>
									<PONumber>'.$PONumber.'</PONumber>
								  </LineItem>
								</LineItems>
							  </Invoice>
							</Invoices>';
					$response = $XeroOAuth->request('POST', $XeroOAuth->url('Invoices', 'core'), array(), $xml);
					if ($XeroOAuth->response['code'] == 200) {
						echo "<script>alert('ok');</script>";
						$invoice = $XeroOAuth->parseResponse($XeroOAuth->response['response'], $XeroOAuth->response['format']);
						echo "" . count($invoice->Invoices[0]). " invoice created in this Xero organisation.";
						if (count($invoice->Invoices[0])>0) {
							echo "The first one is: </br>";
							pr($invoice->Invoices[0]->Invoice);
							if (isset($_GET['multipleInvoice'])) {
								echo "<script>opener.location.reload(true);
								window.close();</script>";
							}
							echo "<script>opener.location.reload(true);
							window.close();</script>";
							outputError($XeroOAuth);
							
							header("Location: ../../../index.php");
						}
					} else {
						echo "<script>opener.location.reload(true);
						window.close();</script>";
						outputError($XeroOAuth);
						
					}
				}
			}
		}
	}
	//testLinks ();
}

