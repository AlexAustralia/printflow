<!DOCTYPE html>
<!--
/**    Name: duplicateQuote.php
 *     Description: 
 *          Creates a copy of the selected quote
 */

-->

<?php
include_once ("resource/db_conn.php");
$CRID = $_GET['CRID'];
$jobType = $_GET['jobType'];
$customerID = $_GET['CID'];
// creates the duplicate record
$query = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM customer_requests WHERE CustomerRequestID='$CRID';");
$query2 = mysql_query("UPDATE tempTable SET CustomerRequestID='', PreviousQuoteID='$CRID'");
$query3 = mysql_query("INSERT INTO customer_requests SELECT * FROM tempTable");
$query4 = mysql_query("DROP TABLE tempTable;");

// duplicates the job type data
$addedEntry = mysql_fetch_array(mysql_query("SELECT * FROM customer_requests ORDER BY CustomerRequestID DESC LIMIT 1"));
$newCRID = $addedEntry['CustomerRequestID'];

if ($jobType == 'flat') {
	$jobquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM flat WHERE fk_quoteID='$CRID';");
	$jobquery2 = mysql_query("UPDATE tempTable SET fk_quoteID='$newCRID'");
	$jobquery3 = mysql_query("INSERT INTO flat SELECT * FROM tempTable");
	$jobquery4 = mysql_query("DROP TABLE tempTable;");
}
else if ($jobType == 'book') {
	$jobquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM book WHERE fk_quoteID='$CRID';");
	$jobquery2 = mysql_query("UPDATE tempTable SET fk_quoteID='$newCRID'");
	$jobquery3 = mysql_query("INSERT INTO book SELECT * FROM tempTable");
	$jobquery4 = mysql_query("DROP TABLE tempTable;");
}
else if ($jobType == 'label') {
	$jobquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM label WHERE fk_quoteID='$CRID';");
	$jobquery2 = mysql_query("UPDATE tempTable SET fk_quoteID='$newCRID'");
	$jobquery3 = mysql_query("INSERT INTO label SELECT * FROM tempTable");
	$jobquery4 = mysql_query("DROP TABLE tempTable;");
}
else if ($jobType == 'artwork') {
	$jobquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM artwork WHERE fk_quoteID='$CRID';");
	$jobquery2 = mysql_query("UPDATE tempTable SET fk_quoteID='$newCRID'");
	$jobquery3 = mysql_query("INSERT INTO artwork SELECT * FROM tempTable");
	$jobquery4 = mysql_query("DROP TABLE tempTable;");
}
else if ($jobType == 'ncr') {
	$jobquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM ncr WHERE fk_quoteID='$CRID';");
	$jobquery2 = mysql_query("UPDATE tempTable SET fk_quoteID='$newCRID'");
	$jobquery3 = mysql_query("INSERT INTO ncr SELECT * FROM tempTable");
	$jobquery4 = mysql_query("DROP TABLE tempTable;");
}
else if ($jobType == 'booklet') {
	$jobquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM booklet WHERE fk_quoteID='$CRID';");
	$jobquery2 = mysql_query("UPDATE tempTable SET fk_quoteID='$newCRID'");
	$jobquery3 = mysql_query("INSERT INTO booklet SELECT * FROM tempTable");
	$jobquery4 = mysql_query("DROP TABLE tempTable;");
}
else if ($jobType == 'envelope') {
	$jobquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM envelope WHERE fk_quoteID='$CRID';");
	$jobquery2 = mysql_query("UPDATE tempTable SET fk_quoteID='$newCRID'");
	$jobquery3 = mysql_query("INSERT INTO envelope SELECT * FROM tempTable");
	$jobquery4 = mysql_query("DROP TABLE tempTable;");
}

// duplicates supplier data
$supplierquery = mysql_query("CREATE TEMPORARY TABLE tempTable SELECT * FROM supplierquotes WHERE fkCustomerRequestID='$CRID';");
$supplierquery2 = mysql_query("UPDATE tempTable SET fkCustomerRequestID='$newCRID', SupplierQuoteID='';");
$supplierquery3 = mysql_query("INSERT INTO supplierquotes SELECT * FROM tempTable");
$supplierquery4 = mysql_query("DROP TABLE tempTable;");

header('Location: customerHistory.php?customerID='.$customerID);


?>