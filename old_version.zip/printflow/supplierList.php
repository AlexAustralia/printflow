<!DOCTYPE html> 
<!-- 
    /** Name: supplierList.php
     *  Description: 
     *          Accessed from quoteRecord.php by clicking "Choose Suppliers" button
     *          Lists all suppliers wit hfunctionality to select up to six for RFQ
     *          Links the following JavaScript files: 
     *              - js/jquery-1.10.2.js
     *              - js/jquery.dataTables.js
     *              - scripts/selectSuppliers.js      
     *              - scripts/scrollingHighlight.js
     *              - scripts/selectRow.js        
     *          Links the following CSS files: 
     *              - style/basic_css.css
     *              - style/record_css.css
     *              - style/supplierSelect_css.css
     */
-->
<?php
include_once ("resource/db_conn.php");
//include_once ("resource/db_connWY.php");
/** Name: mysql_query
 * 	Query database for supplier data.
 *      $query -  string Contains SQL string to query database table
 *      $result -  string Stores the results of the query
 *      Return - Supplier table data
 */
$query = "SELECT * FROM supplier";
$result = mysql_query($query);

// customer request ID
$CRID = $_GET['crID'];


?>


<html> 
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>PrintFlow - Select Suppliers</title>

            <!-- site general style -->
            <link rel="Stylesheet" type="text/css" href="style/basic_css.css"/>    
            <!-- general record style -->
            <link rel="Stylesheet" type="text/css" href="style/record_css.css"/>  
            <!-- specific Quote Record style -->
            <link rel="Stylesheet" type="text/css" href="style/supplierSelect_css.css"/> 
            
            <!-- include jquery and dataTables plugin -->
            <script type="text/javascript" src="js/jquery-1.10.2.js"></script>
            <script type="text/javascript" src="js/jquery.dataTables.js"></script>
            <!-- creating scrollable and searchable table with non scrolling header.
                 functionality from dataTables plugin -->
            <script type="text/JavaScript">
                $(document).ready(function() {
                   $('#sortable').dataTable( {
                       "sScrollY": "435px",
                       "bPaginate": false,
                       "bScrollCollapse": true
                   } );
                } );     
           </script>
            
            <!-- Included javascript functions -->
            <script src="scripts/addSupplierFunction.js"></script>
            <script src="scripts/selectRow.js"></script>
            <script src="scripts/scrollingHighlight.js"></script>
            <script src="scripts/selectedSuppliers.js"></script>

            <script type="text/JavaScript">
                // selected is used for PHP requests such as delete, edit
                var selected;
                selected = null;


                // selectedRow is used for working within the HTML table and refering to the currently highlighted row
                var selectedRow;
                selectedRow = null;
                
                var cRID = <?php echo $CRID; ?>;
                
            </script>
            
            <script type="text/javascript" src="scripts/selectSuppliers.js"></script>
            
    </head>
   
    <body>
        <!-- Top header bar contains page title and action buttons  -->
        <header>
            <div id="title">
                <h1>Select Suppliers for RFQ</h1>            
            </div> <!-- end div - title -->
            <!-- div for tools -->
            <div id="tools">
                <div id="supplierSelectButtons">
                    <input type="submit" value="Select" id="submit" name="submit" onClick="selectSuppliers();"/> 
                    <input type="submit" name="cancel" id="cancel" value="Back to Quote" onClick='window.history.back();'/>
                </div> <!-- end div - supplierSelectButtons -->
            </div> <!-- end div - tools -->
         </header> <!-- end header -->
         
        <!-- Main Content area -->
        <div id="content">            
            <!-- Sortable scrollable table contained in div for styling -->
            <div id="tableContainer">
                <table id="sortable" class="sortable">
                    <!-- header row for table -->
                    <thead class="fixedHeader">
                        <tr class="headerRow">
                            <th class="column1">Select</th> <!-- needs to have check box for each record -->
                            <th class="column2">Supplier Name</th>
                            <th class="column3">Contact</th>		
                            <th class="column4">Email</th>
                            <th class="column5">Web Address</th>
                            <th class="column6">City</th>
                            <th class="column7">Country</th>
							<th class="column8">Category</th>
							<th class="column9" style="display:none">Other categories</th>
                            <th style="display: none;">ID</th>
                        </tr>
                    </thead>
                    <!-- scrollable table body -->
                    <tbody class="scrollContent">
                        <?php
                        if($result) {
                        $temp=0;
                                while($row = mysql_fetch_array($result)) { 
                                        if($temp%2==0){
                                                echo "<tr onmouseover='scrollingHighlight(this,".$row['SupplierID'].")' onclick='selectRow(this,".$row['SupplierID'].")' ondblclick='supplierHistoryDirect(".$row['SupplierID'].")'>";
                                        //color roll
                                        }
                                        else {
                                                echo "<tr onclick='selectRow(this,".$row['SupplierID'].")' ondblclick='supplierHistoryDirect(".$row['SupplierID'].")' >";
                                        }
                        ?>
                                <td TF_colKey="select" name="select" id="select"><input type='checkbox' name='checkbox' id="checkbox"></td>
                                <td TF_colKey="suppliername"><?php echo $row['SupplierName']; ?></td>
                                <td TF_colKey="contact"><?php echo $row['Contact']; ?></td>	
                                <td TF_colKey="email"><a href="mailto:<?php echo $row['Email'];?>"><?php echo $row['Email']; ?></a></td>
                                <td TF_colKey="webAddress"><a href="http://<?php echo $row['WebAddress']; ?>" target="_blank"><?php echo $row['WebAddress']; ?></a></td>
                                <td TF_colKey="city"><?php echo $row['City']; ?></td>
                                <td TF_colKey="country"><?php echo $row['Country']; ?></td>
                                <td TF_colKey="category"><?php echo $row['PrimaryCategory']; ?></td>
                                <td style="display: none;" TF_colKey="categories"><?php echo $row['Notes']; ?></td>
                                <td TF_colKey="supplierID" style="display: none;"><?php echo $row['SupplierID']; ?></td>

                        <?php
                                }
                        }
                        ?>
                    </tbody>
                </table>
            </div> <!-- end div - tableContainer -->
        </div> <!-- end div - content -->
    </body>
</html>
