<!DOCTYPE html>
<!--
    /** Name: deliveryDocket.php
     *  Description:
     *      Accessed from work status
     *      Creates a new delivery docket
     */
-->
<html>
    <head> 
<!-- establishes the connection -->
<?php
include_once ("resource/db_conn.php");

// job ID
$ID = $_GET['jobID'];

// selects the quote
$jobSQL = "SELECT * FROM `job` WHERE `JobID` = '$ID'";
$job = mysql_fetch_array(mysql_query($jobSQL));

$customerRequestID = $job['fkCustomerRequestID'];
$customerRequestSQL = "SELECT * FROM `customer_requests` WHERE `CustomerRequestID`='$customerRequestID'";
$customerRequest = mysql_fetch_array(mysql_query($customerRequestSQL));
$customerID = $customerRequest['fkCustomerID'];

$deliveryQuery = "SELECT * FROM `customer_delivery` WHERE `fk_customerID`='$customerID'";
$delivery = mysql_query($deliveryQuery);

$selectDeliverySQL = "SELECT * FROM `customer_delivery` WHERE `fk_customerID`='$customerID'";
$selectDelivery = mysql_query($selectDeliverySQL);

if(isset($_POST['submit'])) {
	$name = $job['JobTitle'];
	$totalquantity = $job['JobQuantity'];
	$address = $job['DeliveryAddress'];
	$ref = $job['JobID'];
	$deliveryAddress = $_POST['delivery'];
	$boxNumber = $_POST['boxNumber'];
	$boxes = '';
	$jobUpdateSQL = "UPDATE `job` SET `DeliveryAddress`='$deliveryAddress' WHERE `JobID` = '$ID'";
	$jobQuery = mysql_query($jobUpdateSQL);
	for ($i = 1; $i<=$boxNumber; $i++) {
		$boxName = 'box'.$i;
		if(isset($_POST[$boxName])) {
			$boxValue = $_POST[$boxName];
			$boxURL = '&'.$boxName.'='.$boxValue;
			$boxes .= $boxURL;
		}
	}
	header('Location: Sticker.php?name='.$name.'&totalQuantity='.$totalquantity.'&address='.$address.'&ref='.$ref.'&boxNumber='.$boxNumber.$boxes);
	
}
else if(isset($_POST['docket'])) {
	$name = $job['JobTitle'];
	$totalquantity = $job['JobQuantity'];
	$address = $job['DeliveryAddress'];
	$ref = $job['JobID'];
	$deliveryAddress = $_POST['delivery'];
	$boxNumber = $_POST['boxNumber'];
	$boxes = '';
	$jobUpdateSQL = "UPDATE `job` SET `DeliveryAddress`='$deliveryAddress' WHERE `JobID` = '$ID'";
	$jobQuery = mysql_query($jobUpdateSQL);
	for ($i = 1; $i<=$boxNumber; $i++) {
		$boxName = 'box'.$i;
		if(isset($_POST[$boxName])) {
			$boxValue = $_POST[$boxName];
			$boxURL = '&'.$boxName.'='.$boxValue;
			$boxes .= $boxURL;
		}
	}
	header('Location: generateDocket.php?name='.$name.'&totalQuantity='.$totalquantity.'&address='.$address.'&ref='.$ref.'&boxNumber='.$boxNumber.$boxes);
}
else if(isset($_POST['dispatch'])) {
	mysql_query("UPDATE `job` SET `JobStatus`='Dispatch' WHERE `JobID`='$ID'");
	header('Location: deliveryView.php');
}
else if(isset($_POST['cancel'])) {
	header('Location: deliveryView.php');
}
else if(isset($_POST['delete'])) {
	$code = $_POST['deliveryCode'];
	$sql = "DELETE FROM `customer_delivery` WHERE `fk_customerID`='$customerID' AND `Code`='$code'";
	mysql_query($sql);
}
else if(isset($_POST['save'])) {
	$deliverySelect = $_POST['delivery'];
	$deliveryCode = $_POST['deliveryCode'];
	$deliveryName = $_POST['deliveryName'];
	$deliveryStreet = $_POST['deliveryStreet'];
	$deliveryProvince = $_POST['deliveryProvince'];
	$deliverySuburb = $_POST['deliverySuburb'];
	$deliveryState = $_POST['deliveryState'];
	$deliveryCountry = $_POST['deliveryCountry'];
	$deliveryPostcode = $_POST['deliveryPostcode'];
	$deliveryNotes = $_POST['deliveryNotes'];
	echo '<script>alert("'.$deliveryCode.'");</script>';
	// a new delivery has been entered
	if (($deliveryCode != "") && ($deliverySelect == "none")) {
		$deliverySQL = "INSERT INTO `customer_delivery`(`fk_customerID`,`Code`,`Name`,`Street`,`Province`,`Suburb`,`State`,`Country`,`Postcode`,`Notes`) VALUES ('$customerID','$deliveryCode','$deliveryName','$deliveryStreet','$deliveryProvince','$deliverySuburb','$deliveryState','$deliveryCountry','$deliveryPostcode','$deliveryNotes')";
	}

	// changing a current delivery
	if (($deliveryCode != "") && ($deliverySelect != "none")) {
		$deliverySQL = "UPDATE `customer_delivery` SET `Code`='$deliveryCode', `Name`='$deliveryName', `Street`='$deliveryStreet', `Province`='$deliveryProvince', `Suburb`='$deliverySuburb', `State`='$deliveryState', `Country`='$deliveryCountry', `Postcode`='$deliveryPostcode', `Notes`='$deliveryNotes' WHERE `fk_customerID`='$customerID' AND `Code`='$deliverySelect'";
	}
	$deliveryResult = mysql_query($deliverySQL);
	
	header('Location: deliveryDocket.php?jobID='.$ID);
}

?>

        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="generator" content="HAPedit 3.1">
        <title >PrintFlow - Create Delivery Docket</title>
        
        <!-- add favicon -->        
        <link rel="icon" type="image/png" href="images/logo-transparent.png" />
        
        <!-- site general style -->
        <link rel="Stylesheet" type="text/css" href="style/record_css.css"/>         
         <!-- page specific style -->
        <link rel="stylesheet" type="text/css" href="style/jobCreate_css.css"/>
        
        <script type="text/javascript" src="scripts/createNewJob.js"></script>
        
       
        <!-- creating scrollable and searchable table with non scrolling header.
             functionality from dataTables plugin -->
        <script type="text/JavaScript">
           
			function showQuantities() {
				var number = document.getElementById('boxNumber').value;
				var list = document.getElementById('quantities');
				var table = document.getElementById('displayTable');
				var html = "";
				// deletes all the current boxes
				while (table.rows.length > 15) {
					table.deleteRow(-1);
				}
				// makes the new boxes
				for (var i=1;i<=number;i++) {
					//html += '<tr><td></td><td></td></tr>';
					var row = table.insertRow(-1);
					row.className="quantityRow";
					var cell1 = row.insertCell(0);
					var cell2 = row.insertCell(1);
					cell1.innerHTML = 'Box '+i+' Qty: ';
					cell2.innerHTML = '<input onkeyup="keepEqual()" size="6" type="text" name="box'+i+'" id="box'+i+'" class="quantityBox"></input>';
				}
				//list.innerHTML = html;
			}
			
			function keepEqual() {
				var checked = document.getElementById('duplicate').checked;
				var inputs = document.getElementsByClassName('quantityBox');
				if (checked == true) {
					for (var i=1;i<=inputs.length;i++) {
						var box = 'box' + i;
						document.getElementById(box).value = document.getElementById('box1').value;
					}
				}
			}
			var deliveryCodeArray = [];
			var deliveryNameArray = [];
			var deliveryStreetArray = [];
			var deliveryProvinceArray = [];
			var deliverySuburbArray = [];
			var deliveryStateArray = [];
			var deliveryCountryArray = [];
			var deliveryPostcodeArray = [];
			var deliveryNotesArray = [];
			
			deliveryCodeArray.push("");
			deliveryNameArray.push("");
			deliveryStreetArray.push("");
			deliveryProvinceArray.push("");
			deliverySuburbArray.push("");
			deliveryStateArray.push("");
			deliveryCountryArray.push("");
			deliveryPostcodeArray.push("");
			deliveryNotesArray.push("");
			
			function changeDelivery(index) {
				document.getElementById("deliveryCode").value = deliveryCodeArray[index];
				document.getElementById("deliveryName").value = deliveryNameArray[index];
				document.getElementById("deliveryStreet").value = deliveryStreetArray[index];
				document.getElementById("deliveryProvince").value = deliveryProvinceArray[index];
				document.getElementById("deliverySuburb").value = deliverySuburbArray[index];
				document.getElementById("deliveryState").value = deliveryStateArray[index];
				document.getElementById("deliveryCountry").value = deliveryCountryArray[index];
				document.getElementById("deliveryPostcode").value = deliveryPostcodeArray[index];
				document.getElementById("deliveryNotes").value = deliveryNotesArray[index];
			}
			
        </script>
        
    </head>

    <body>
        <!-- Top header bar contains page title and action buttons  -->
        <header>
            <div id="heading">
                <h1>Create Delivery Docket</h1>            
            </div> <!-- end div - title -->
            <!-- div for tools -->
            <div id="tools">
            </div> <!-- end div - tools -->
         </header> <!-- end header -->
         
         <!-- main content -->
         <div id="content">
            <form method="post">
				<!-- table for layout -->
				<table id="displayTable">
					<tr>
						<td width="200px">Title:</td>
						<td><?php echo $job['JobTitle']; ?></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>Delivery:</td>
						<td><select name="delivery" id="delivery" onChange="changeDelivery(this.selectedIndex)">
								<option value="none">Select Delivery</option>
								<?php
								if($selectDelivery) {
									while($row = mysql_fetch_array($selectDelivery)) {
										if ($row['Code'] == $job['DeliveryAddress']) {
											echo '<option selected="selected" value="'.$row['Code'].'">'.$row['Code'].'</option>';
										}
										else {
											echo '<option value="'.$row['Code'].'">'.$row['Name'].'</option>';
										}
										echo '<script>';
										echo 'deliveryCodeArray.push("'.$row['Code'].'");';
										echo 'deliveryNameArray.push("'.$row['Name'].'");';
										echo 'deliveryStreetArray.push("'.$row['Street'].'");';
										echo 'deliveryProvinceArray.push("'.$row['Province'].'");';
										echo 'deliverySuburbArray.push("'.$row['Suburb'].'");';
										echo 'deliveryStateArray.push("'.$row['State'].'");';
										echo 'deliveryCountryArray.push("'.$row['Country'].'");';
										echo 'deliveryPostcodeArray.push("'.$row['Postcode'].'");';
										echo 'deliveryNotesArray.push("'.$row['Notes'].'");';
										echo '</script>';
									}
								}
								
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td>Code:</td>
						<td><input name="deliveryCode" id="deliveryCode"/></td>
					</tr>
					<tr>
						<td>Name:</td>
						<td><input name="deliveryName" id="deliveryName"/></td>
					</tr>
					<tr>
						<td>Street:</td>
						<td><input name="deliveryStreet" id="deliveryStreet"/></td>
					</tr>
					<tr>
						<td>Province:</td>
						<td><input name="deliveryProvince" id="deliveryProvince"/></td>
					</tr>
					<tr>
						<td>Suburb:</td>
						<td><input name="deliverySuburb" id="deliverySuburb"/></td>
					</tr>
					<tr>
						<td>State:</td>
						<td><input name="deliveryState" id="deliveryState"/></td>
					</tr>
					<tr>
						<td>Country:</td>
						<td><input name="deliveryCountry" id="deliveryCountry"/></td>
					</tr>
					<tr>
						<td>Postcode:</td>
						<td><input name="deliveryPostcode" id="deliveryPostcode"/></td>
					</tr>
					<tr>
						<td>Notes:</td>
						<td><input name="deliveryNotes" id="deliveryNotes"/></td>
					</tr>
					<tr>
						<td><br /><br /><br /></td>
						<td><input type="submit" name="save" id="save" value="Save Changes" /><input type="submit" name="delete" id="delete" value="Delete" /></td>
					</tr>
					<tr>
						<td>Quantity:</td>
						<td><?php echo $job['JobQuantity']; ?></td>
					</tr>
					<tr>
						<td>Number of Boxes:</td>
						<td><select id="boxNumber" name="boxNumber" onchange="showQuantities()">
								<option value="0">Select Number</option>
								<?php
								for ($i=1;$i<=30;$i++) {
									echo '<option value="'.$i.'">'.$i.'</option>';
								}
								?>
							</select>
							<label for="duplicate">All Equal</label>
							<input type="checkbox" id="duplicate" />
						</td>
					</tr>
				</table>
				
				
				
				
                    
                <!-- Save and Cancel buttons -->
                <div class="buttons">
                    <input type="submit" name="submit" id="submit" value="Delivery Sticker" />
					<input type="submit" name="docket" id="docket" value="Delivery Docket" />
					<input type="submit" name="dispatch" id="dispatch" value="Dispatch" />
                    <input type="submit" name="cancel" id="cancel" value="Close" onclick="window.location('deliveryView.php');" />
                </div> <!-- end div - buttons -->
            </form>  
        </div> <!-- end div - content -->
    </body>
</html>    
